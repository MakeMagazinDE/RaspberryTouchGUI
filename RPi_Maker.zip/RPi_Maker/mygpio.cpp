#include "mygpio.h"
#include <QDebug>
#include "wiringPi.h"

myGPIO::myGPIO( QObject * parent ): QObject( parent )
{
    wiringPiSetupGpio() ;
;
}
myGPIO::myGPIO(const int &_pin, QObject * parent) :
     QObject( parent ),
     m_pin( _pin ){
 }
myGPIO::~myGPIO() {
   // qDebug() << "destruct.\n"<<m_pin ;
    pinMode (m_pin, INPUT);
    pullUpDnControl (m_pin, PUD_OFF) ;

 }
int myGPIO::pin() const {
   // qDebug() << "myGPIO::pin() has been called.\n" ;
    return m_pin;
}

void myGPIO::setPin(const int &pin) {
   // qDebug() << "myGPIO::setPin(const int &) has been called with:"<<pin<<"\n" ;
    if(pin==m_pin)return;
    pinMode (m_pin, INPUT);
    pullUpDnControl (m_pin, PUD_OFF) ;
    m_pin=pin;
    emit pinChanged();
    pinMode (m_pin, INPUT);
    pullUpDnControl (m_pin, PUD_OFF) ;
}

int myGPIO::mode() const {
    return m_mode;
}
void myGPIO::setMode(const int &mode) {
     if( m_mode==mode)return;
     m_mode=mode;
     switch(m_mode) {
        case -1:pinMode (m_pin, INPUT);pullUpDnControl (m_pin, m_state+1) ;break;
        case 0: pinMode(m_pin,INPUT);pullUpDnControl (m_pin, PUD_OFF) ;break;
        case 1:digitalWrite(m_pin,m_state);pinMode (m_pin, OUTPUT);break;
     }
     emit modeChanged();
}

int myGPIO::value() const{

   /*if (m_value==digitalRead (m_pin)) return m_value;
   else{
        m_value=digitalRead (m_pin);
        emit valueChanged();
        return m_value;
   }*/
  //  updateValue();
    return m_value;
}

int myGPIO::state() const{
    return m_state;
}

void myGPIO::setState(const int &state) {
    m_state=state;
    switch(m_mode) {
        case -1:pullUpDnControl (m_pin, m_state+1);break;
        case 0:break;
        case 1:digitalWrite(m_pin,m_state);break;
    }
    emit stateChanged();
}


void myGPIO::updateValue(){
    if (m_value!=digitalRead (m_pin)){
              m_value=digitalRead (m_pin);
              emit valueChanged();
    }
}

void myGPIO::setServo(double winkel, unsigned int freq=50,double low=1,double high=2){
     unsigned int resolution=1023;
     double tick = double(1000)/(resolution*freq);
     int position=int ((low+(high-low)*winkel)/tick);

     if (!(position==m_pwm_position)){
         m_pwm_position=position;
         pinMode (m_pin, PWM_OUTPUT) ;
         pwmSetMode (PWM_MODE_MS);
         pwmSetRange (resolution);
         pwmSetClock (18750/freq);
         pwmWrite(m_pin, m_pwm_position);
     }
}

