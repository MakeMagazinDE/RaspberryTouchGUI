#include <QtWidgets/QApplication>
//#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQmlComponent>
#include <QtDebug>
#include  "mygpio.h"
#include "wiringPi.h"

int main(int argc, char *argv[])
{
   qputenv("QT_QUICK_CONTROLS_STYLE", "material");
   QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
   QApplication app(argc, argv);
       app.setOrganizationName("maker");
       app.setOrganizationDomain("heise.de");
       app.setApplicationName("RPI_Maker");
    QQmlApplicationEngine engine;
    qmlRegisterType<myGPIO>("Wire", 1,0, "GPIO");
    engine.load(QUrl(QLatin1String("qrc:/main.qml")));

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}


