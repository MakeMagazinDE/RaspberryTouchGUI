#ifndef MYGPIO_H
#define MYGPIO_H

#include <QObject>

class myGPIO: public QObject
{
    Q_OBJECT
    Q_PROPERTY( int pin READ pin WRITE setPin NOTIFY pinChanged )
    Q_PROPERTY( int mode READ mode WRITE setMode NOTIFY modeChanged )
    Q_PROPERTY( int value READ value NOTIFY valueChanged )
    Q_PROPERTY( int state READ state WRITE setState NOTIFY stateChanged )
    Q_ENUMS(mode)
    Q_ENUMS(state)
public:
    enum mode { Input=0, Output=1, PWM_Output=2, InputPullUp=-1 };
    enum state { Low=0,High=2};
    myGPIO(QObject * parent =0);
    virtual ~myGPIO();
    myGPIO(const int &_pin, QObject * parent=0);

    int pin() const;
    void setPin(const int &);

    int mode() const;
    void setMode(const int &);

    int value() const;

    int state() const;
    void setState(const int &);

signals:
    void pinChanged();
    void modeChanged();
    void valueChanged();
    void stateChanged();

public slots:
    void updateValue();
    void setServo(double winkel,unsigned int freq,double low, double high);

private:
    int m_pin;
    int m_mode;
    int m_value;
    int m_state;
    int m_pwm_position;

};

#endif // MYGPIO_H
